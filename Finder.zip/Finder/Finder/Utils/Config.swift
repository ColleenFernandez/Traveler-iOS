//
//  Config.swift
//  Finder
//
//  Created by djay mac on 03/02/15.
//  Copyright (c) 2015 DJay. All rights reserved.
//

import UIKit

// if you get any errors, contact me on skype: djay.in or email me chupa@djay.in

// make sure you read the readMe.pdf file.

// Terms of Service URl or else App will not be approved
var termsUrl = "https://en.zedinternational.net/hitobito-privacy-policy"

var appUrl = "https://itunes.apple.com/app/id1029414770"

// change this text for sharing
var shareText = "Hey guys, download Hito Bito to find local matches https://itunes.apple.com/app/id1029414770"

//client parse appId:-BJGGmGMEWh56W04I7rJ1FVcsgQtYNdmGrArByojf
//client parse appSecret:-o4AT2ie5TBNnRlnLnf01qO72iB4CAC4ZH6eQhfUF

// Parse Setting
var appId = "BJGGmGMEWh56W04I7rJ1FVcsgQtYNdmGrArByojf"
var appSecret = "o4AT2ie5TBNnRlnLnf01qO72iB4CAC4ZH6eQhfUF"


// initial about me text
var aboutme = "😍"

// text ocolor
var colorText = UIColor.black










