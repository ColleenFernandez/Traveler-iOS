//
//  DetailsUser.swift
//  Finder
//
//  Created by djay mac on 28/01/15.
//  Copyright (c) 2015 DJay. All rights reserved.
//

import UIKit

class DetailsUser: UIView {

    @IBOutlet weak var nameAge: UILabel!
    @IBOutlet weak var distance: UILabel!
    @IBOutlet weak var about: UITextView!
}
