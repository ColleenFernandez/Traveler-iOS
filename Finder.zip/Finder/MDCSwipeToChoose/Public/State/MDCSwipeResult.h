//
// MDCSwipeResult.h
//
// Copyright (c) 2014 to present, Brian Gesiak @modocache
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//

#import <UIKit/UIKit.h>
#import "MDCSwipeDirection.h"

typedef void (^MDCSwipedOnCompletionBlock)(void);

/*!
 * An object representing the result of a swipe.
 * This is provided as an argument to `MDCSwipeToChooseOnChosenBlock` callbacks.
 */
@interface MDCSwipeResult : NSObject

/*!
 * The view that was swiped.
 */
@property (nonatomic, strong) UIView *view;

/*!
 * The translation of the swiped view; i.e.: the distance it has been panned
 * from its original location.
 */
@property (nonatomic, assign) CGPoint translation;

/*!
 * The final direction of the swipe.
 */
@property (nonatomic, assign) MDCSwipeDirection direction;

/*!
 * A callback to be executed after any animations performed by the `MDCSwipeOptions`
 * `onChosen` callback.
 */
@property (nonatomic, copy) MDCSwipedOnCompletionBlock onCompletion;

@end
